import React from 'react'
import { Link } from 'react-router-dom'
import { Home, Car, MessageSquare, Bell, User, Wrench, Mail } from 'lucide-react'

const Navbar: React.FC = () => {
  return (
    <nav className="bg-indigo-600 text-white">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="text-xl font-bold">AutoComunidad</Link>
          <div className="flex space-x-4">
            <Link to="/" className="flex items-center hover:bg-indigo-700 px-3 py-2 rounded">
              <Home className="mr-1" />
              Inicio
            </Link>
            <Link to="/marketplace" className="flex items-center hover:bg-indigo-700 px-3 py-2 rounded">
              <Car className="mr-1" />
              Marketplace
            </Link>
            <Link to="/talleres-cercanos" className="flex items-center hover:bg-indigo-700 px-3 py-2 rounded">
              <Wrench className="mr-1" />
              Talleres
            </Link>
            <Link to="/mensajes" className="flex items-center hover:bg-indigo-700 px-3 py-2 rounded">
              <Mail className="mr-1" />
              Mensajes
            </Link>
            <Link to="/notificaciones" className="flex items-center hover:bg-indigo-700 px-3 py-2 rounded">
              <Bell className="mr-1" />
              Notificaciones
            </Link>
            <Link to="/perfil" className="flex items-center hover:bg-indigo-700 px-3 py-2 rounded">
              <User className="mr-1" />
              Perfil
            </Link>
          </div>
        </div>
      </div>
    </nav>
  )
}

export default Navbar